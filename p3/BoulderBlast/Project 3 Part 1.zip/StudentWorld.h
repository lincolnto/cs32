#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Level.h"
#include "Actor.h"
#include <vector>
#include <string>
#include <sstream>
using namespace std;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)	
	{}

	virtual int init();
	virtual int move();
	virtual void cleanUp();
	virtual int loadALevel();

	virtual bool isSpaceEmpty(int x, int y); // Returns true if space at (x,y) is empty
private:
	Actor * m_player;
	vector<Actor *> m_actors;
	virtual string levelName();

};

#endif // STUDENTWORLD_H_
