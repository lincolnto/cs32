#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

int StudentWorld::init()
{
	loadALevel();
	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	m_player->doSomething();
	// This code is here merely to allow the game to build, run, and terminate after hitting enter a few times 
	decLives();
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	return;
}

int StudentWorld::loadALevel()
{
	string	curLevel = levelName();
	Level	lev(assetDirectory());
	Level::LoadResult result = lev.loadLevel(curLevel);
	if (result == Level::load_fail_file_not_found ||
		result == Level::load_fail_bad_format)
		return -1; //	something	bad	happened!
	// otherwise the load was successful and you can access the
	// contents of the level � here�s an example

	// Allocate all actors
	for (int x = 0; x <= VIEW_WIDTH - 1; x++)
	{
		for (int y = 0; y <= VIEW_HEIGHT - 1; y++)
		{
			int startX = x, startY = y;

			Level::MazeEntry item = lev.getContentsOf(x, y);
			switch (item)
			{
			case Level::empty:
				break;
			case Level::wall:
				m_actors.push_back(new Wall(startX, startY, this));
				break;
			case Level::player:
				m_player = new Player(startX, startY, this);
				break;
			// Implement below this line after part 1
			case Level::hole:
				break;
			case Level::exit:
				break;
			case Level::horiz_snarlbot:
				break;
			case Level::vert_snarlbot:
				break;
			case Level::kleptobot_factory:
				break;
			case Level::angry_kleptobot_factory:
				break;
			case Level::jewel:
				break;
			case Level::restore_health:
				break;
			case Level::extra_life:
				break;
			case Level::ammo:
				break;
			}
		}
	}
	return 0; // THIS IS INCORRECT
}

bool StudentWorld::isSpaceEmpty(int x, int y) // Currently checks if it is not a wall
{
	string	curLevel = levelName();
	Level	lev(assetDirectory());
	Level::LoadResult result = lev.loadLevel(curLevel);
	Level::MazeEntry item = lev.getContentsOf(x, y);
	return (item != Level::wall); // change to Level::empty later!
}

string StudentWorld::levelName()
{
	// Creates a string with the file name of the level
	ostringstream lvlNum;
	int level = getLevel();
	if (level >= 0 && level <= 9)
		lvlNum << "level0" << level << ".dat";
	else if (level > 9 && level <= 99)
		lvlNum << "level" << level << ".dat";
	return lvlNum.str();
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
