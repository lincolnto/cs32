#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, Direction dir, StudentWorld *p) 
		: GraphObject(imageID, startX, startY, dir) 
	{
		m_world = p;
	};

	virtual void doSomething()	{  return;  }
	void setAlive(bool x)	{  m_alive = x;  }
	bool isAlive() const {  return m_alive;  }
	StudentWorld* getWorld() { return m_world; }
	
private:
	bool m_alive;
	StudentWorld* m_world;
	/*
	int			m_imageID; --
	bool		m_visible;
	double		m_x; --
	double		m_y; --
	double		m_destX; --
	double		m_destY; --
	double		m_brightness; --
	int			m_animationNumber; --
	Direction	m_direction; --
	*/
};

class Character : public Actor // Players/robots
{
public:
	Character(int imageID, int startX, int startY, int hp, int ammo, StudentWorld *p)
		: Actor(imageID, startX, startY, right, p) 
	{
		setVisible(true);
		setAlive(true);
		m_hp = hp; 
		m_ammo = ammo;
	};
private:
	int m_hp;
	int m_ammo;

};

class Player : public Character
{
public:
	Player(int startX, int startY, StudentWorld *p) 
		:  Character(IID_PLAYER, startX, startY, 20, 20, p)
	{};
	virtual void doSomething();
private:
};

class Wall : public Actor
{
public:
	Wall(int startX, int startY, StudentWorld *p) : Actor(IID_WALL, startX, startY, none, p)
	{
		setVisible(true);
		setAlive(true);
	};
private:
};
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
