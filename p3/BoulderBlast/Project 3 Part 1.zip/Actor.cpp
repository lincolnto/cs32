#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething()
{
	if (!isAlive())	return; // player is dead!
	int ch;
	int curX = getX(), curY = getY();
	if (getWorld()->getKey(ch))
	{
		switch (ch)
		{
		case KEY_PRESS_UP:
			if (getWorld()->isSpaceEmpty(curX, curY + 1))
				moveTo(curX, curY + 1);
			setDirection(up);
			break;
		case KEY_PRESS_DOWN:
			if (getWorld()->isSpaceEmpty(curX, curY - 1))
				moveTo(curX, curY - 1);
			setDirection(down);
			break;
		case KEY_PRESS_RIGHT:
			if (getWorld()->isSpaceEmpty(curX + 1, curY))
				moveTo(curX + 1, curY);
			setDirection(right);
			break;
		case KEY_PRESS_LEFT:
			if (getWorld()->isSpaceEmpty(curX - 1, curY))
				moveTo(curX - 1, curY);
			setDirection(left);
			break;
		case KEY_PRESS_SPACE:
			break;
		case KEY_PRESS_ESCAPE:
			break;
		}
	}
		return;
}
