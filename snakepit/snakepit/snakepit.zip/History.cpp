#include <iostream>
#include "History.h"

History::History(int nRows, int nCols)
{
	m_rows = nRows;
	m_cols = nCols;
}

bool record(int r, int c)
{
	if (m_pit->destroyOneSnake())
	{

	}
}
